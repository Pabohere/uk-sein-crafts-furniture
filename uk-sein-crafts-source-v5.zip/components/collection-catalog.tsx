"use client";

import Link from "next/link";
import { useState } from "react";
import { products } from "@/lib/products";

const filters = [
  ["All", "All products"],
  ["Seating", "Seating"],
  ["Tables", "Tables"],
  ["Decor", "Decor"],
] as const;

const slugFor = (name: string) => name.toLowerCase().replaceAll(" ", "-");

export default function CollectionCatalog() {
  const [filter, setFilter] = useState("All");
  const visibleProducts = products.filter(
    (product) => filter === "All" || product.c === filter,
  );

  return (
    <>
      <div className="collection-tools" aria-label="Product categories">
        {filters.map(([key, label]) => (
          <button
            key={key}
            type="button"
            className={filter === key ? "active" : ""}
            onClick={() => setFilter(key)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="product-grid">
        {visibleProducts.map((product) => (
          <Link
            className="product motion-card product-link"
            href={`/collection/${slugFor(product.n)}`}
            key={product.n}
          >
            <div className="product-image">
              <span>NEW</span>
              <img src={product.i} alt={product.n} />
            </div>
            <div className="product-meta">
              <small>{product.c}</small>
              <b>{product.p}</b>
            </div>
            <h3>{product.n}</h3>
            <div className="sizes" aria-label="Available sizes">
              <span>S</span><span className="selected">M</span><span>L</span>
            </div>
            <span className="add">View details&nbsp; +</span>
          </Link>
        ))}
      </div>
    </>
  );
}
