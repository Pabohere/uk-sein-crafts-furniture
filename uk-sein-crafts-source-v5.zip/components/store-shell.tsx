"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowRight, BookOpen, CalendarDays, FileText, Mail, Phone, Plus, Search, ShoppingBag } from "lucide-react";
import { products } from "@/lib/products";

export { products } from "@/lib/products";
const tickerMessages = ["Nationwide deliveries", "Handcrafted locally"];

function BrandLogo({ footer = false }: { footer?: boolean }) {
  return <span className={`brand-logo${footer ? " footer-logo" : ""}`}><img src="/uk-sein-logo-transparent.png" alt="Uk Sein Crafts & Furniture" /></span>;
}

export function Header() {
  const [search, setSearch] = useState("");
  return <>
    <div className="promo" aria-label="Nationwide deliveries and handcrafted locally">
      <span className="promo-rotator" aria-hidden="true">
        {Array.from({ length: 20 }, (_, index) => <span key={index}>{tickerMessages[index % tickerMessages.length]}</span>)}
      </span>
    </div>
    <nav className="nav">
      <Link className="brand" href="/"><BrandLogo /></Link>
      <div className="nav-links">
        <Link href="/">Home</Link><Link href="/collection">Collection</Link><Link href="/events">Events</Link><Link href="/about">About us</Link><Link href="/contact">Contact us</Link>
      </div>
      <div className="nav-actions">
        <div className="site-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search" /></div>
        <button className="bag" type="button" aria-label="Shopping bag"><ShoppingBag size={18} /></button>
        <Link className="admin-link" href="/admin">Admin</Link>
      </div>
    </nav>
  </>;
}

export function Cards() {
  return <div className="product-grid">{products.map((product) => <article className="product motion-card" key={product.n}>
    <div className="product-image"><img src={product.i} alt={product.n} /><span>NEW</span></div>
    <div className="product-meta"><div><p>{product.c}</p><h3>{product.n}</h3><div className="product-sizes"><button type="button">S</button><button className="chosen" type="button">M</button><button type="button">L</button></div></div><b>{product.p}</b></div>
    <button className="add" type="button">Add to basket <Plus size={17} /></button>
  </article>)}</div>;
}

export function ContactDrawer() {
  const rows = [["Call us", "09 771 778 064", Phone], ["Email us", "ukseinmmlocalcrafts@gmail.com", Mail], ["Request a callback", "Select a time", CalendarDays], ["Request a quote", "Discuss your requirements", FileText], ["Product brochure", "Download PDF or view online", BookOpen]];
  return <main><Header /><div className="contact-underlay"><section className="page-hero"><p className="eyebrow">GET IN TOUCH</p><h1>Contact Uk Sein</h1><p>We would love to help you find the right piece for your home.</p></section></div><aside className="contact-drawer"><Link className="drawer-close" href="/">×</Link><h2>Contact Us</h2>{rows.map(([title, sub, Icon]: any) => <button className="contact-row" type="button" key={title}><Icon size={28} /><span><b>{title}</b><small>{sub}</small></span><ArrowRight size={18} /></button>)}</aside></main>;
}

export function Footer() {
  return <footer><div className="footer-brand"><BrandLogo footer /></div><div><h3>Showroom</h3><p>No. 5, Nawaday Street<br />Yangon, Myanmar</p></div><div><h3>Contact</h3><p>09 771 778 064<br />09 784 058 903</p></div></footer>;
}
