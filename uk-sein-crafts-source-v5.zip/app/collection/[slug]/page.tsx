import Link from "next/link";
import { notFound } from "next/navigation";
import { Footer, Header } from "@/components/store-shell";
import { products } from "@/lib/products";

const slugFor = (name: string) => name.toLowerCase().replaceAll(" ", "-");

export default async function ProductDetail({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = products.find((item) => slugFor(item.n) === slug);
  if (!product) notFound();

  return (
    <main>
      <Header />
      <section className="detail motion-in">
        <img src={product.i} alt={product.n} />
        <div>
          <Link className="back-link" href="/collection">← Back to collection</Link>
          <p className="eyebrow">{product.c}</p>
          <h1>{product.n}</h1>
          <b>{product.p}</b>
          <p>
            A handcrafted piece made to bring natural texture and a calm, lived-in
            feeling to your home. Select a size and add it to your basket.
          </p>
          <div className="sizes" aria-label="Select size">
            <span>S</span><span className="selected">M</span><span>L</span>
          </div>
          <button className="gold-button" type="button">Add to basket&nbsp; +</button>
        </div>
      </section>
      <Footer />
    </main>
  );
}
