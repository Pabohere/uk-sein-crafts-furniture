import { Footer, Header } from "@/components/store-shell";
import CollectionCatalog from "@/components/collection-catalog";

export default function Collection() {
  return (
    <main>
      <Header />
      <section className="page-hero motion-in">
        <p className="eyebrow">SHOP ALL</p>
        <h1>The collection</h1>
        <p>Handmade pieces designed for warm, considered living.</p>
      </section>
      <section className="shop"><CollectionCatalog /></section>
      <Footer />
    </main>
  );
}
