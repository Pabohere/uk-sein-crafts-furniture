"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { defaultCatalog, readCatalog, type CatalogProduct } from "@/lib/catalog";

const slugFor = (name: string) => name.toLowerCase().replaceAll(" ", "-");

export default function CollectionCatalog() {
  const [filter, setFilter] = useState("All");
  const [catalog, setCatalog] = useState<CatalogProduct[]>(defaultCatalog);
  useEffect(() => { const refresh = () => setCatalog(readCatalog()); refresh(); window.addEventListener("storage", refresh); return () => window.removeEventListener("storage", refresh); }, []);
  const categories = ["All", ...Array.from(new Set(catalog.map((product) => product.category)))];
  const visibleProducts = catalog.filter(
    (product) => filter === "All" || product.category === filter,
  );

  return (
    <>
      <div className="collection-tools" aria-label="Product categories">
        {categories.map((key) => (
          <button
            key={key}
            type="button"
            className={filter === key ? "active" : ""}
            onClick={() => setFilter(key)}
          >
            {key === "All" ? "All products" : key}
          </button>
        ))}
      </div>
      <div className="product-grid">
        {visibleProducts.map((product) => (
          <Link
            className="product motion-card product-link"
            href={`/collection/${product.id}`}
            key={product.id}
          >
            <div className="product-image">
              <span>NEW</span>
              <img src={product.image} alt={product.name} />
            </div>
            <div className="product-meta">
              <small>{product.category}</small>
              <b>{product.price}</b>
            </div>
            <h3>{product.name}</h3>
            <div className="sizes" aria-label="Available sizes">
              {product.sizes.map((size) => <span className={size === "M" ? "selected" : ""} key={size}>{size}</span>)}
            </div>
            <span className="add">View details&nbsp; +</span>
          </Link>
        ))}
      </div>
    </>
  );
}
