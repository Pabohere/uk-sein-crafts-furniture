import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Uk Sein Crafts & Furniture | Yangon",
  description: "Handmade rattan furniture and local crafts from Yangon, Myanmar.",
  other: {
    "codex-preview": "Uk Sein Crafts & Furniture",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
